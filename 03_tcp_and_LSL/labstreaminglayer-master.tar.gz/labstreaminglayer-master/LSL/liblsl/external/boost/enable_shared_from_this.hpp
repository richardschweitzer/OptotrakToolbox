#include <lslboost/enable_shared_from_this.hpp>

#ifndef LSLBOOST_NAMESPACE_DECLARED
#define LSLBOOST_NAMESPACE_DECLARED
namespace lslboost { }; namespace boost = lslboost;
#endif
