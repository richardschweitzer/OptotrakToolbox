#include <lslboost/detail/endian.hpp>

#ifndef LSLBOOST_NAMESPACE_DECLARED
#define LSLBOOST_NAMESPACE_DECLARED
namespace lslboost { }; namespace boost = lslboost;
#endif
