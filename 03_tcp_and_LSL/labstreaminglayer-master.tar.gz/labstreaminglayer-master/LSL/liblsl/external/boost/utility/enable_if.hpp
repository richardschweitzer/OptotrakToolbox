#include <lslboost/utility/enable_if.hpp>

#ifndef LSLBOOST_NAMESPACE_DECLARED
#define LSLBOOST_NAMESPACE_DECLARED
namespace lslboost { }; namespace boost = lslboost;
#endif
