import deps_worker
deps_worker.unstrip_all()
