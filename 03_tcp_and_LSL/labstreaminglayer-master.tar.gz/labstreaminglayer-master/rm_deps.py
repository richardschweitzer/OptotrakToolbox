import deps_worker
deps_worker.strip_all()
