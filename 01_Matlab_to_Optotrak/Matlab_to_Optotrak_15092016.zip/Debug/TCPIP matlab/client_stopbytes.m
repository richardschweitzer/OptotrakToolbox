% http://iheartmatlab.blogspot.de/2008/08/tcpip-socket-communications-in-matlab.html

% CLIENT connect to a server and read a message
%
% Usage - message = client(host, port, number_of_retries)
function message = client_stopbytes(host, port, number_of_retries, start_byte, stop_byte, end_byte)

import java.net.Socket
    import java.io.*

    % set number of retries if empty
    
    retry        = 0;
    input_socket = [];
    message      = [];

    while true

        retry = retry + 1;
        
        if ((number_of_retries > 0) && (retry > number_of_retries))
            fprintf(1, 'Too many retries\n');
            break;
        end
        
        try
            fprintf(1, 'Retry %d connecting to %s:%d\n', ...
                    retry, host, port);

            % throws if unable to connect
            input_socket = Socket(host, port);

            % get a buffered data input stream from the socket
            input_stream   = input_socket.getInputStream;
            d_input_stream = DataInputStream(input_stream);

            fprintf(1, 'Connected to server\n');

            % read data from the socket - wait a short time first
            %pause(0.5);
            
%             bytes_expected = 100;
%             message_started = 0;
%             
%             %pause(10);
%             stop = 0;
%             tic;
%             while stop == 0 % start reading input
%                 % check whether there is data in the input_stream
% %                bytes_available = input_stream.available;
% %                if bytes_available>0 % start parsing input when bytes are available
%                     current_byte = d_input_stream.readByte; % get current byte
%                     % if the current_byte is '[' and no message is active
%                     if current_byte==start_byte && message_started==0
%                         message_started = 1;
%                         message = zeros(1, bytes_expected);
%                         i = 1;
%                     % if the current_byte is ']' and the message is active
%                     elseif current_byte==stop_byte && message_started==1
%                         message_started = 0;
%                         char(message)
%                     % if message is active, then read input
%                     elseif message_started==1
%                         message(i) = current_byte;
%                         i = i+1;
%                     % if current_byte is the end_byte, then terminate
%                     elseif char(current_byte)==end_byte
%                         stop = 1;
%                     end
% %                end
%             end
%             toc;
            
            pause(10);
            tic;
            i = 0;
            while 1
                current_utf = d_input_stream.readUTF;
                %toc;
                %i = i+1
                %current_utf
                if current_utf == end_byte
                    break
                end
            end
            toc;
                
%                 message = zeros(1, bytes_available, 'uint8');
%                 i = 0;
%                 end_message = 0;
%                 while end_message == 0
%                     % check how many bytes are available
%                     bytes_available = input_stream.available;
%                     fprintf(1, 'Available %d bytes\n', bytes_available);
%                 
%                     % read out
%                     i = i+1;
%                     current_byte = d_input_stream.readByte;
%                     if char(current_byte)==sep_byte
%                         end_message = 1;
%                     elseif char(current_byte)==stop_byte    
%                         end_message = 1;
%                         stop = 1;
%                     else 
%                         message(i) = current_byte;
%                     end
%                 end
%                 message = char(message)
%             end
                    
          
            
            % cleanup
            input_socket.close;
            break;
            
        catch
            if ~isempty(input_socket)
                input_socket.close;
            end

            % pause before retrying
            pause(1);
   end
    end
end