%%% auxiliary functions %%%
function clean_connection(server_socket, output_socket)
    if ~isempty(server_socket)
                server_socket.close
    end
    if ~isempty(output_socket)
        output_socket.close
    end
end