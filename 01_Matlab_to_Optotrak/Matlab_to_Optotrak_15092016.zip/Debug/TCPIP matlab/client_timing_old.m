% test server--client timing: CLIENT

import java.net.ServerSocket
import java.net.Socket
import java.io.*


%%% parameters.  %%%
% general
duration = 10; % in seconds
number_of_retries = 20;
% client data. this is the CLIENT
this_ip = '172.29.10.14';
input_port_client = 2000; % the input port of the client must be the output port of the server
input_socket_client  = [];
% server data
server_ip = '172.29.7.82';
output_port_client = 2001; % the output port of the client must be the input port of the server
server_client  = [];
output_socket_client  = [];



message = 'hello, I am the client';


%%% 1. Setup connections %%%
% http://iheartmatlab.blogspot.de/2008/08/tcpip-socket-communications-in-matlab.html


%%%%%% 1.1 the input stream from server to client (we are the client) %%%%%%%
retry = 0;
connected_input = 0;

while connected_input == 0
    
        retry = retry + 1;
        if ((number_of_retries > 0) && (retry > number_of_retries))
            fprintf(1, 'Too many retries\n');
            break;
        end
        
        try
            fprintf(1, 'Retry %d connecting to server %s:%d\n', ...
                    retry, server_ip, input_port_client);

            % throws if unable to connect
            input_socket_client = Socket(server_ip, input_port_client);

            % get a buffered data input stream from the socket
            input_stream_client   = input_socket_client.getInputStream;
            d_input_stream_client = DataInputStream(input_stream_client);

            fprintf(1, 'Server connected to Client \n');      
            
            connected_input = 1;
            
        catch %ME
            if ~isempty(input_socket_client)
                input_socket_client.close;
            end

            % pause before retrying
            pause(1);
            %rethrow(ME);
        end
end


%%%%%%% 1.2 the output stream from client to server (we are the client) %%%%%%%%
retry = 0;
connected_output = 0;

while connected_output == 0

        retry = retry + 1;
        
        if ((number_of_retries > 0) && (retry > number_of_retries))
                fprintf(1, 'Too many retries\n');
                break;
        end

        try

            fprintf(1, ['Try %d waiting for server to connect to this ' ...
                        'client on port : %d\n'], retry, output_port_client);

            % wait for 1 second for client to connect server socket
            client_socket = ServerSocket(output_port_client);
            client_socket.setSoTimeout(1000);

            output_socket_client = client_socket.accept;

            fprintf(1, 'Server accepted output connection from Client\n');

            output_stream_client   = output_socket_client.getOutputStream;
            d_output_stream_client = DataOutputStream(output_stream_client);
            
            connected_output = 1;
            
        catch
            
            if ~isempty(client_socket)
                client_socket.close
            end
            if ~isempty(output_socket_client)
                output_socket_client.close
            end

            % pause before retrying
            pause(1);
        end
end


pause(1);

%%% 2. Send some data to server and wait for it to come back %%%
n = 10000;
times = zeros(1, n);
% send a message to server
pause(0.4);
for i = 1:n
    %disp('Message to server: ');
    %disp(message);
    received_something = 0;
    d_output_stream_client.writeUTF(message);
    tic;
    % wait for its answer
    while received_something == 0
        if input_stream_client.available > 0
            message_from_server = d_input_stream_client.readUTF;
            times(i) = toc;
            %disp(times(i));
            %disp('Message from server: ');
            %disp(message_from_server);
            received_something = 1;
        end
    end
end
d_output_stream_client.writeUTF(';');

%%% 3. Close connections %%%
% clean up
client_socket.close;
input_socket_client.close;
output_socket_client.close;

 