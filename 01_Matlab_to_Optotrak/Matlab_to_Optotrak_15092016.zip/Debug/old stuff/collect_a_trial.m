% Written by Jarrod Blinch, November 13th, 2010
% Available from motorbehaviour.wordpress.com
% with additions by Richard Schweitzer

% Bottomline: this is a blocking routine. It drops several samples
%clear all;
 
collection_num_markers_1 = 3;     		% optotrak
collection_num_markers_2 = 6; 
collection_frequency = 200;     		% Hz
collection_duration = 4;        		% s
total_frame_num = collection_frequency * collection_duration;
cam_filename = 'Aligned20160728';     % .cam file for sensor. % name of sensor: C3-04864

[a b] = Matlab_to_Optotrak('TransputerLoadSystem', collection_num_markers_1, collection_num_markers_2, ...
    collection_frequency, collection_duration, cam_filename, 0);
if (a ~= 0)
error('TransputerLoadSystem died!');
b
end
pause(1);
[a b] = Matlab_to_Optotrak('OptotrakActivateMarkers'); %#ok<NASGU>
if (a ~= 0)
    error('OptotrakActivateMarkers died!');
end
 
[a b] = Matlab_to_Optotrak('DataBufferInitializeFile', '', 'test_001.P01');
 
% Array b will contain the current IRAD locations.
tic;
[a b tstart tend] = Matlab_to_Optotrak('DataGetLatest3D');
toc;
tdur = tend - tstart;
tdur

display('IRED locations:');
display(b(4:end));

% create array for 3d data
sample_length = length(b);
save_here = zeros(total_frame_num, sample_length);
time_save_here = zeros(6, total_frame_num);
time_write_buffer = zeros(1, total_frame_num);

 
[a b] = Matlab_to_Optotrak('DataBufferStart');
 
data_buffer_done = false;
i = 1;
while (data_buffer_done == false)
    loop_start = tic;

    % write data to buffer
    tic;
    [a, b, ts, te] = Matlab_to_Optotrak('DataBufferWriteData');
    if (a ~= 0)
        display('Warning: DataBufferWriteData died!');
    end
    if (b == 1)
        data_buffer_done = true;
    end
    time_save_here(2, i) = toc;
    time_save_here(1, i) = (te - ts)/1000;

    % retrieve realtime data
    % Can be used to peek at the data during collection.
    tic;
    [a, b, ts, te] = Matlab_to_Optotrak('DataGetLatest3D');
    time_save_here(4, i) = toc;
    time_save_here(3, i) = (te - ts)/1000;
    time_save_here(5, i) = b(1);

    save_here(i,:) = b;
    time_save_here(6, i) = toc(loop_start); % time for loop execution

    i = i+1;
    
end
 

% Convert the R and O files to C and V.
[a b] = Matlab_to_Optotrak('FileConvert', '', 'test_001.P01');
 
optotrak_array = open_ndi_bin_file('C#test_001.P01');
 
figure;
hold on;
title('IRED locations');
plot3(optotrak_array(:,1), optotrak_array(:,2), optotrak_array(:,3), 'r');
plot3(optotrak_array(:,4), optotrak_array(:,5), optotrak_array(:,6), 'g');
plot3(optotrak_array(:,7), optotrak_array(:,8), optotrak_array(:,9), 'b');

 
[a b] = Matlab_to_Optotrak('OptotrakDeActivateMarkers'); %#ok<NASGU>
if (a ~= 0)
    display('Warning: OptotrakDeActivateMarkers died!');
end
[a b] = Matlab_to_Optotrak('TransputerShutdownSystem');
if (a ~= 0)
    display('Warning: TransputerShutdownSystem died!');
end
 
% Release the Matlab_to_Optotrak.mexw32 file, which allows it
% to be compiled in Visual C++ if needed.
clear mex;

%%% plot stuff
xlimits = [0 total_frame_num];
% let's plot the duration of each request
figure(123);
subplot(3,1,1);
plot(time_save_here(4,:), '.')
title('receive duration');
xlim(xlimits);
subplot(3,1,2);
plot(time_save_here(2,:), '.')
title('buffer write duration');
xlim(xlimits);
subplot(3,1,3);
plot(time_save_here(6,:), '.')
title('loop duration');
xlim(xlimits);

% let's plot the timestamps of each DataReceive
time_between_samples = [];
for i = 1:(length(save_here(:,13))-1)
    time_between_samples(i) = save_here(i+1,13)-save_here(i,13);
end    
figure(124);
plot(time_between_samples, '.');
title('time between samples [ms]');
xlim(xlimits);
ylim([3000*(-1/collection_frequency) 3000*(1/collection_frequency)]);
