%cd C:\Users\sysop\Documents\Visual Studio 2015\Projects\Matlab_to_Optotrak\Debug

Matlab_to_Optotrak_old() % this is the old version it doesnt do anything