% [ndi_array] = open_ndi_bin_file(filename)
%
% Written by Jarrod Blinch, November 6th, 2010
% Available from motorbehaviour.wordpress.com
function [ndi_array] = open_ndi_bin_file(filename)
 
 
fid = fopen(filename, 'r');
fread(fid, 1, 'char');                      % 32
item_total = fread(fid, 1, 'short');        % items per frame
subitem_total = fread(fid, 1, 'short');     % subitems per frame
column_total = item_total * subitem_total;
frame_total = fread(fid, 1, 'int');         % number of frames
fread(fid, 1, 'float');                     % collection frame frequency
fread(fid, 60, 'char=>char');               % user comments
fread(fid, 60, 'char=>char');               % system comments
fread(fid, 30, 'char=>char');               % file description
fread(fid, 1, 'short');                     % cutoff filter frequency
fread(fid, 8, 'char=>char');                % time of collection
fread(fid, 1, 'short');                     % unused?
fread(fid, 8, 'char=>char');                % date of collection
fread(fid, 73, 'char');                     % extended headed and unused
 
ndi_array = ones(frame_total,column_total) .* NaN;
for frame_num = 1:frame_total
    for column_num = 1:column_total
        data = fread(fid, 1, 'float');
        if (data < -100000) % technically, it is EE EE EE EE or -3.697314e+28
            data = NaN;
        end
        ndi_array(frame_num,column_num) = data;
    end
end
 
fclose(fid);
 
 
end